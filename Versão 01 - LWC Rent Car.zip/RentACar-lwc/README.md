# RentACar Application

> This is the Lightning Web Component version of the RentACar application. If you are looking for the old Aura version, click [here](https://github.com/choudharymanish8585/RentACar).


RentACar is an application built on Salesforce Platform to demonstrate the Salesforce UI Frameworks like LWC or Aura. The application allows end users to search for different car, get their current locations on map and easily review it.