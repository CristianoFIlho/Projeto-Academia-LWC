declare module "@salesforce/resourceUrl/Leaflet" {
    var Leaflet: string;
    export default Leaflet;
}