declare module "@salesforce/apex/CarExperience.getExperiences" {
  export default function getExperiences(param: {carId: any}): Promise<any>;
}
