declare module "@salesforce/apex/CarSearchResultController.getCars" {
  export default function getCars(param: {carTypeId: any}): Promise<any>;
}
