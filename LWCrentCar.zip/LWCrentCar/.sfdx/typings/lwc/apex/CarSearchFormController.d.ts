declare module "@salesforce/apex/CarSearchFormController.getCarTypes" {
  export default function getCarTypes(): Promise<any>;
}
