declare module "@salesforce/resourceUrl/cars" {
    var cars: string;
    export default cars;
}