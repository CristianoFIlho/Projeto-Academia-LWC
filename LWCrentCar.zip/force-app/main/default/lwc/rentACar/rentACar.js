import { LightningElement } from 'lwc';

export default class RentACar extends LightningElement {}